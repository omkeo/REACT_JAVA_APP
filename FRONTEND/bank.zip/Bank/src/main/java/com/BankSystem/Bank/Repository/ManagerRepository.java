package com.BankSystem.Bank.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BankSystem.Bank.Entity.Manager;

public interface ManagerRepository extends JpaRepository<Manager, Long>{
	Optional<Manager> findByUsername(String username);

}
