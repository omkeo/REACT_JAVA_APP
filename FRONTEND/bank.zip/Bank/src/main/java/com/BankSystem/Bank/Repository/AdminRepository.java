package com.BankSystem.Bank.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BankSystem.Bank.Entity.Account;
import com.BankSystem.Bank.Entity.Admin;


public interface AdminRepository extends JpaRepository<Admin, Long> {
	Optional<Admin> findByUsername(String username);


}
